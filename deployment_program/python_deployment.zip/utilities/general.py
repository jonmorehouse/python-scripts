
# THIS PROGRAM IS FOR HANDLING THE TRAILING SLASH OF A DIRECTORY / URL
def slash(input):
	
	if input[-1] != "/":
		input +="/"
		
	return input
	

	