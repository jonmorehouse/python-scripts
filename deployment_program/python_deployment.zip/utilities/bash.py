import os, commands


# THIS IS A UTILITIES CLASS TO HELP WITH FUNCTIONS THAT ARE COMMON AROUND THE BASH SHELL

# THIS FUNCTION IS USEFUL FOR COMBINING FILES DYNAMICALLY
def combine(output_file, input_files):
	# ASSUMES THE INPUT FILES ARE FULL PATHS
	# WILL CHECK FOR THE EXISTISTENCE OF EACH ONE
	
	command = "cat "
	
	for input_file in input_files:
		
		command += input_file + " "
	
	command += "> %s" % output_file 
	
	commands.getstatusoutput(command)	


# USES THE INSTALLED YUI EDITOR TO PERFORM THIS FUNCTION
def compress(input_file):
	
	tmp_file = "/tmp/deployment_temp"
	compress = "yuicompressor %s > %s" % (input_file, tmp_file)
	move = "mv %s %s" % (tmp_file, input_file)
		
	commands.getstatusoutput(compress)
	commands.getstatusoutput(move)

		



