# THIS FILE IS RESPONSIBLE FOR ALL OF THE SETTINGS AND DIRECTORIES FOR DIFFERENT DEPLOYMENT FILES
from configuration import Configuration
from utilities.mysql import Mysql
from modules import *


# WILL ALSO BE RESPONSIBLE FOR QUERYING DB 

class Rip_it_up_world(Configuration):
	
	static_url = "s3://rip_it_up_world/static/"
	static_type = "amazon"
	static_directory = "/Users/MorehouseJ09/Documents/production_development/rip_it_up_world/current/static/"
	
	media_url = "s3://rip_it_up_world/media/"
	media_type = "amazon"
	media_directory = "/Users/MorehouseJ09/Documents/production_development/rip_it_up_world/media/"
	
	site_url = "http://ripitupworld-morehousej09.dotcloud.com/"
	server = "dotcloud"
		
	local_database = "rip_it_up_world"
	remote_database = "rip_it_up_world"
	
	local_archive = "/Users/MorehouseJ09/Documents/production_development/rip_it_up_world/archive/" #local archive -- assuming 
	live_archive = "s3://rip_it_up_world/archive/"
	
	site_status = False
	
	def __init__(self):
				
		self.javascript() #if there is custom javascript just extend this class and "over-ride the parent function!"
		self.css()
	
	
	
		# THIS WILL RUN THE ENTIRE THING
		# 1.) Generate CSS
		# 2.) Generate Javascript
		
				

		



