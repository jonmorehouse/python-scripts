class Compression(object):
	
	
	
	
	
	
	
	
	

	