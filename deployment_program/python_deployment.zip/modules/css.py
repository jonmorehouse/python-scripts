import utilities 


class Css():
	
	def __init__(self, configuration):
		
		self.configuration = configuration
	
	
		
		
	
	
	
	

	