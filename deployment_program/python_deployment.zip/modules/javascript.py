from utilities.mysql import Mysql
import utilities #import all utilities and use it as a namespace

class Javascript(object):#this is an object that is responsible for getting site information and compiling information--pass it a configuration object
	
	def __init__(self, configuration):
		
		self.configuration = configuration #can then call self.configuration.get() for anything needed -- we want to have the db loaded 
		
		self.mysql = Mysql(configuration.get("local_database"))
		
		
		self.__combine_files() #will go through the list in order and "cat them together"
			
	
	
	def __combine_files(self):#will get the files and combine them accordingly -- need to get the unique types
		
		rows = self.mysql.unique("header_javascript", "page_id") #get the unique pages in this site
		page_ids = []
		
		for row in rows:
			page_ids.append(row['page_id'])
		
		# ACTUALLY GATHER THE FILES FOR EACH ONE
		for page_id in page_ids:
			ordered_list = self.__file_list(page_id)
			
			if ordered_list:
				url = self.__combine(page_id, ordered_list) #name returns the correct value and then we update the database with this!
				self.__update(page_id, "testing123")
				
			
			
		
		return True
		# create the file from the file list
		# update the database with this information -- need to query the old one!
		# Actually run the combine file command
		
	
		
	def __file_list(self, page_id):#this program will be responsible for compiling for each page_id
		
		files = self.mysql.where("status", False).where("page_id", page_id).select(["url", "js_type"]).get("header_javascript")
		
		
		if files: #the files exist == need to sort them
			
			ordered_files = []
			site_wide = []
			utilities = []
			modules = []
			pages = []
			other = []
			
			for _file in files:
				if _file['js_type'] == "site_wide":
					site_wide.append(_file)
				
				elif _file['js_type'] == "utilities":
					utilities.append(_file)
				
				elif _file['js_type'] == "modules":
					modules.append(_file)
				
				elif _file['js_type'] == "pages":
					pages.append(_file)
				
				elif _file['js_type'] != "live":
					other.append(_file)
			whole_list = [site_wide, utilities, modules, pages, other]
			
			for _list in whole_list:
				ordered_files.extend(_list)
					
			return ordered_files
					
				
		else:
			return False
		
			
	
			
	def __combine(self, page_id, _list):
		
		directory = utilities.general.slash(self.configuration.get("static_directory"))
		
		name = page_id
		if page_id == "all":
			name = "site_wide"
			
		file_name = directory + "javascript/live/%s.js" % name
		file_paths = []
			
		for item in _list:
			path = directory + item['url']
			file_paths.append(path)
			
		# NOW CONCATENATE ALL THE FILES:
		
		utilities.bash.combine(file_name, file_paths)
		utilities.bash.compress(file_name)
			
		
		
		
	
		
	def __update(self, page_id, url): #will be responsible for updating the database so that we are responsible for this new file!
		
		# DELETE ANY OTHER LIVE FILES IN THE DB -- (UNLINK THEM!)
		self.mysql.where("status", True).where("page_id", page_id).delete("header_javascript")
		
		
		# NOW INSERT WITH THE NEW NAME
		columns = ["page_id", "url", "status", "js_type"] #columns for this particular site setup
		values = [page_id, url, True, "live"]#values for this particular site setup
		
		self.mysql.insert("header_javascript", values, columns) #the database is now update properly
				
	
		
	







	
	
	
	
	
	
	
	
	
