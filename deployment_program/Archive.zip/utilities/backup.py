# class backup is responsible for taking directories, comparing the files, side by side and then returning a list of local files and their destinations
# 1.) Give to directory roots that are the same and generate a list of absolute files for each one (3 arrays, file_name from root, live absolute, local absolute)
# 2.) For each of the files, compare the date given, if local is greater than new, then put them in each of the new arrays (destination and source) pop them out of the list
# 3.) go through each list and copy the files correspondingly -- this method can be replaced in the children classes

import commands, os.path


class Backup(object):

	def __init__(self, source, destination):

		if self._exists(source) and self._exists(destination):

			self.source = source
			self.destination = destination
			self._backup()

		else:
			print "Bad Directory"
			return False #bad directory was given -- need to look into this should not happen

	# PROTECTED METHODS

	# THIS IS THE GENERAL BACKUP SCHEMA, TO BE USED IF BOTH DIRECTORIES ARE LOCALIZED
	def _backup(self):

		source = self.source
		destination = self.destination
		# GENERATE THE LIST'S FOR EACH ONE
		source_list = self._source_list(source)
		file_list = self.file_list(source_list, source)
		# destination_list = self._destination_list(destination)







	def _exists(self, directory): #will return true / false depending upon whether the folders exist


		if os.path.exists(directory):
			return True

		else:
			return False


		
	def _source_list(self, directory): #generates a list of files in the source directory (absolute)

		return self.__directory_items(directory)


	def _destination_list(self, directory): #generates a list of files in the destination directory (absolute)

		destination_list = self.__directory_items(directory)

		file_list = self.file_list

		for item in destination_list:

			# get just the file name for each file in this list
			name = str.replace(directory, "")

			# now verify that each file is in the actual file list that we are using
			if name not in file_list:

				self._remove(item) #remove the item
				destination_list.remove(item) #remove item from destination list

		return destination_list

	# FILE LIST IS GIVEN PARAMETERS IN CASE THE SOURCE IS S3
	def _file_list(self, file_list, source_directory): #generates a list of files in the local directory (relative)

		# need to erase the self.source from each of the files
		for item in file_list:
			item = item.replace(source_directory, "")

		for i in file_list:
			print i

		return file_list


	def _compare(self, source_file, destination_file): #will compare the files in each list and creates two new lists of files that should be copied over

		command = "diff %s %s" % (source_file, destination_file)

		print commands.getstatusoutput(command)

	def _remove(self, file, directory = False):

		# will remove the file that is given -- don't use in development until ready
		command = "rm %s" % file

		# commands.getstatusoutput(command)
 


	# PRIVATE METHODS

	def __directory_items(self, directory):

		if directory[-1] == "/":
			directory = directory[:-1]

		command = "find %s" % directory
		results = commands.getoutput(command)

		file_list = results.split()

		return file_list




