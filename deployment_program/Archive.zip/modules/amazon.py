import os.path, commands
from utilities import backup




# THIS CLASS WILL BE RESPONSIBLE FOR BACKING UP FILES TO THE AMAZON S3 SERVER

	


class Amazon(backup.Backup):

	def __init__(self, source, destination):

		super(Amazon, self).__init__(source, destination)
		self.amazon = False

	
	def __is_amazon(self, directory):

		amazon = directory.find("s3://")

		if amazon != -1: #means that the s3 was found in the directory
			return True

		else:
			return False

	# check whether a file is the same
	def _exists(self, directory):

		if self.__is_amazon(directory): #we can verify that this is an amazon directory
			return True

		# if not __is_amazon, we still need to check if it is a local directory

		else: #this directory is localized
			return super(Amazon, self)._exists(directory)

	def _source_list(self, directory):

		if not self.__is_amazon(directory): #this is a regular directory -- return the parent method
			return super(Amazon, self)._source_list(directory)

		else: #return the s3 list items!
			return self.__file_list(directory)			

	def _destination_list(self, directory):

		if not self.__is_amazon(self.destination): #this is a regular directory return the parent method
			return super(Amazon, self).destination_list()

		else: #we want to return the amazon only file_list
			return self.__file_list(self.destination)

	# REMVOE THE FILE from S3 if an amazon file
	def _remove(self, file, directory):

		if not self.__is_amazon(directory):
			return super(Amazon, self).remove(file)

		else:

			# need to delete from s3cmd
			command = "s3cmd del %" % file
			# commands.getstatusoutput(command)


	# THIS FILE list expects to see a full amazon folder and will return by using the s3cmd tool on terminal
	def __file_list(self, directory):

		if directory[-1] == "/":
			directory = directory[:-1]

		command = "s3cmd ls %s" % directory

		results = commands.getoutput(command).split() #get the results into a list item

		counter = 0

		for item in results:

			if counter == 2: #every third item we need to reset it because we only add the three items
				file_list.append(item)
				counter = 0
	
			else:
				counter += 1 #increase the counter









			














